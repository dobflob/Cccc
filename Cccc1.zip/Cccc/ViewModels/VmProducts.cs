﻿using System;

namespace Cccc.ViewModels
{
    public class VmProducts
    {
        public Guid ProductID { get; set; }

        public string ProductName { get; set; }
        public string QuantityPerUnit { get; set; }
        public decimal? UnitPrice { get; set; }
    }
}