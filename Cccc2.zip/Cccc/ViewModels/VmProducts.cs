﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Cccc.ViewModels
{
    public class VmProducts
    {
        public Guid ProductID { get; set; }

        [Display(Name = "Product Name")]
        public string ProductName { get; set; }

        [Display(Name = "Quantity Per Unit")]
        public string QuantityPerUnit { get; set; }

        [Display(Name = "Unit Price")]
        public decimal? UnitPrice { get; set; }
    }
}